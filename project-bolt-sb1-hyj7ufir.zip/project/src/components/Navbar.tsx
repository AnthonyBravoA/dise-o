import { ShoppingCart, User, UtensilsCrossed, LogOut } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';

interface NavbarProps {
  onShowCart: () => void;
  onShowAuth: () => void;
  onShowOrders: () => void;
}

export function Navbar({ onShowCart, onShowAuth, onShowOrders }: NavbarProps) {
  const { user, signOut } = useAuth();
  const { cartCount } = useCart();

  return (
    <nav className="fixed top-0 w-full bg-white shadow-md z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-br from-pink-400 to-pink-600 p-2 rounded-full">
              <UtensilsCrossed className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-500 to-pink-700 bg-clip-text text-transparent">
              Don Lolo
            </h1>
          </div>

          <div className="flex items-center space-x-4">
            {user ? (
              <>
                <button
                  onClick={onShowOrders}
                  className="px-4 py-2 text-gray-700 hover:text-pink-600 transition-colors font-medium"
                >
                  Mis Pedidos
                </button>
                <button
                  onClick={onShowCart}
                  className="relative p-2 text-gray-700 hover:text-pink-600 transition-colors"
                >
                  <ShoppingCart className="h-6 w-6" />
                  {cartCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-pink-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                      {cartCount}
                    </span>
                  )}
                </button>
                <button
                  onClick={signOut}
                  className="flex items-center space-x-2 px-4 py-2 bg-pink-500 text-white rounded-full hover:bg-pink-600 transition-colors"
                >
                  <LogOut className="h-4 w-4" />
                  <span>Salir</span>
                </button>
              </>
            ) : (
              <button
                onClick={onShowAuth}
                className="flex items-center space-x-2 px-6 py-2 bg-gradient-to-r from-pink-500 to-pink-600 text-white rounded-full hover:from-pink-600 hover:to-pink-700 transition-all shadow-md"
              >
                <User className="h-4 w-4" />
                <span>Iniciar Sesión</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
