/*
  # Restaurant Don Lolo Database Schema

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key, references auth.users)
      - `email` (text)
      - `full_name` (text)
      - `phone` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `categories`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `created_at` (timestamptz)
    
    - `products`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `price` (numeric)
      - `image_url` (text)
      - `category_id` (uuid, references categories)
      - `available` (boolean)
      - `created_at` (timestamptz)
    
    - `cart_items`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `product_id` (uuid, references products)
      - `quantity` (integer)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `orders`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `total` (numeric)
      - `status` (text) - pending, preparing, ready, delivered, cancelled
      - `payment_method` (text) - card, yape
      - `payment_status` (text) - pending, completed, failed
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `order_items`
      - `id` (uuid, primary key)
      - `order_id` (uuid, references orders)
      - `product_id` (uuid, references products)
      - `quantity` (integer)
      - `price` (numeric)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to manage their own data
    - Add policies for viewing public product information

  3. Sample Data
    - Insert categories (Entradas, Platos Principales, Bebidas, Postres)
    - Insert sample products for the restaurant
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text,
  phone text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view categories"
  ON categories FOR SELECT
  TO authenticated
  USING (true);

-- Create products table
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  price numeric(10, 2) NOT NULL,
  image_url text,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  available boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view available products"
  ON products FOR SELECT
  TO authenticated
  USING (available = true);

-- Create cart_items table
CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity integer NOT NULL DEFAULT 1 CHECK (quantity > 0),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, product_id)
);

ALTER TABLE cart_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own cart items"
  ON cart_items FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own cart items"
  ON cart_items FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own cart items"
  ON cart_items FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own cart items"
  ON cart_items FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create orders table
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  total numeric(10, 2) NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'preparing', 'ready', 'delivered', 'cancelled')),
  payment_method text NOT NULL CHECK (payment_method IN ('card', 'yape')),
  payment_status text NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'completed', 'failed')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create order_items table
CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id),
  quantity integer NOT NULL CHECK (quantity > 0),
  price numeric(10, 2) NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own order items"
  ON order_items FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert own order items"
  ON order_items FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM orders
      WHERE orders.id = order_items.order_id
      AND orders.user_id = auth.uid()
    )
  );

-- Insert categories
INSERT INTO categories (name, description) VALUES
  ('Entradas', 'Deliciosos aperitivos para comenzar'),
  ('Platos Principales', 'Nuestras especialidades de la casa'),
  ('Bebidas', 'Refrescantes bebidas y jugos'),
  ('Postres', 'Dulces delicias para terminar')
ON CONFLICT DO NOTHING;

-- Insert sample products
INSERT INTO products (name, description, price, category_id, image_url) 
SELECT 
  'Causa Limeña',
  'Papa amarilla, pollo, aguacate y mayonesa',
  18.00,
  (SELECT id FROM categories WHERE name = 'Entradas' LIMIT 1),
  'https://images.pexels.com/photos/1640772/pexels-photo-1640772.jpeg?auto=compress&cs=tinysrgb&w=800'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Causa Limeña');

INSERT INTO products (name, description, price, category_id, image_url) 
SELECT 
  'Ceviche de Pescado',
  'Pescado fresco, limón, cebolla y camote',
  32.00,
  (SELECT id FROM categories WHERE name = 'Entradas' LIMIT 1),
  'https://images.pexels.com/photos/3655916/pexels-photo-3655916.jpeg?auto=compress&cs=tinysrgb&w=800'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Ceviche de Pescado');

INSERT INTO products (name, description, price, category_id, image_url) 
SELECT 
  'Anticuchos',
  'Brochetas de corazón marinadas con especias',
  25.00,
  (SELECT id FROM categories WHERE name = 'Entradas' LIMIT 1),
  'https://images.pexels.com/photos/5409010/pexels-photo-5409010.jpeg?auto=compress&cs=tinysrgb&w=800'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Anticuchos');

INSERT INTO products (name, description, price, category_id, image_url) 
SELECT 
  'Lomo Saltado',
  'Lomo de res, cebolla, tomate y papas fritas',
  38.00,
  (SELECT id FROM categories WHERE name = 'Platos Principales' LIMIT 1),
  'https://images.pexels.com/photos/5410400/pexels-photo-5410400.jpeg?auto=compress&cs=tinysrgb&w=800'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Lomo Saltado');

INSERT INTO products (name, description, price, category_id, image_url) 
SELECT 
  'Ají de Gallina',
  'Pollo deshilachado en crema de ají amarillo',
  28.00,
  (SELECT id FROM categories WHERE name = 'Platos Principales' LIMIT 1),
  'https://images.pexels.com/photos/8753657/pexels-photo-8753657.jpeg?auto=compress&cs=tinysrgb&w=800'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Ají de Gallina');

INSERT INTO products (name, description, price, category_id, image_url) 
SELECT 
  'Arroz con Mariscos',
  'Arroz con mariscos frescos y especias',
  42.00,
  (SELECT id FROM categories WHERE name = 'Platos Principales' LIMIT 1),
  'https://images.pexels.com/photos/8753656/pexels-photo-8753656.jpeg?auto=compress&cs=tinysrgb&w=800'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Arroz con Mariscos');

INSERT INTO products (name, description, price, category_id, image_url) 
SELECT 
  'Seco de Res',
  'Res guisada con cilantro y frejoles',
  35.00,
  (SELECT id FROM categories WHERE name = 'Platos Principales' LIMIT 1),
  'https://images.pexels.com/photos/5409011/pexels-photo-5409011.jpeg?auto=compress&cs=tinysrgb&w=800'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Seco de Res');

INSERT INTO products (name, description, price, category_id, image_url) 
SELECT 
  'Chicha Morada',
  'Bebida tradicional de maíz morado',
  8.00,
  (SELECT id FROM categories WHERE name = 'Bebidas' LIMIT 1),
  'https://images.pexels.com/photos/5946619/pexels-photo-5946619.jpeg?auto=compress&cs=tinysrgb&w=800'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Chicha Morada');

INSERT INTO products (name, description, price, category_id, image_url) 
SELECT 
  'Inca Kola',
  'La bebida del Perú',
  6.00,
  (SELECT id FROM categories WHERE name = 'Bebidas' LIMIT 1),
  'https://images.pexels.com/photos/2775860/pexels-photo-2775860.jpeg?auto=compress&cs=tinysrgb&w=800'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Inca Kola');

INSERT INTO products (name, description, price, category_id, image_url) 
SELECT 
  'Limonada',
  'Refrescante limonada natural',
  7.00,
  (SELECT id FROM categories WHERE name = 'Bebidas' LIMIT 1),
  'https://images.pexels.com/photos/96974/pexels-photo-96974.jpeg?auto=compress&cs=tinysrgb&w=800'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Limonada');

INSERT INTO products (name, description, price, category_id, image_url) 
SELECT 
  'Suspiro Limeño',
  'Dulce de leche con merengue',
  12.00,
  (SELECT id FROM categories WHERE name = 'Postres' LIMIT 1),
  'https://images.pexels.com/photos/1998634/pexels-photo-1998634.jpeg?auto=compress&cs=tinysrgb&w=800'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Suspiro Limeño');

INSERT INTO products (name, description, price, category_id, image_url) 
SELECT 
  'Mazamorra Morada',
  'Postre tradicional de maíz morado',
  10.00,
  (SELECT id FROM categories WHERE name = 'Postres' LIMIT 1),
  'https://images.pexels.com/photos/5946743/pexels-photo-5946743.jpeg?auto=compress&cs=tinysrgb&w=800'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Mazamorra Morada');

INSERT INTO products (name, description, price, category_id, image_url) 
SELECT 
  'Picarones',
  'Buñuelos con miel de chancaca',
  14.00,
  (SELECT id FROM categories WHERE name = 'Postres' LIMIT 1),
  'https://images.pexels.com/photos/3026808/pexels-photo-3026808.jpeg?auto=compress&cs=tinysrgb&w=800'
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Picarones');